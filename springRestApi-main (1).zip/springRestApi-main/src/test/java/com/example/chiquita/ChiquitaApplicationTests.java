package com.example.chiquita;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChiquitaApplicationTests {

    @Test
    void contextLoads() {
    }

}
