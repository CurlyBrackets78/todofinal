package com.example.chiquita.model;

public record JwtRequest(String username, String password) {
}
